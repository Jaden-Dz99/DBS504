<?php
/**
 * Edit Links
 *
 * Allows users to Edit information of a link already in the database
 *
 * @author      Isaac Dinh <20027354@tafe.wa.edu.au>
 * @file        links-edit.php
 * @version     1.1
 * @editd     2019-05-07
 * @copyright   This work is licensed under Creative Commons
 *              Attribution-ShareAlike 3.0 Australia License.
 */

$title = "ICTDBS504 | JDZ | Links | Add";
require_once "functions.php";
require_once "connection.php";
require_once "header.php";


if (!isset($_POST)||!isset($_POST['link'])) {
    $error = ["warning" => "Cannot come directly to this page"];
} else {

    $linkToFind = $_POST['link'];
// Read the links from the db into an array
    $sqlRead = "SELECT t.id, t.title, t.description, t.url, t.tags, t.created_at, t.updated_at FROM links as t WHERE id = :linkToFind";
// execute the SQL
    $stmt = $conn->prepare($sqlRead);
    $stmt->bindParam(':linkToFind', $linkToFind);
    $stmt->execute();
// store results in array
    $link = $stmt->fetch();

    ?>
    <!-- Details about this demo file -->
    <div class="row">
        <div class="col">
            <h1 class="mt-4"><?= $title; ?></h1>
            <h2 class="text-muted">Edit Link</h2>
            <div class="row">
                <p class="col mb-2"><a href="links-browse.php" class="btn btn-primary mb-1">Browse all</a></p>
            </div>
        </div>
    </div>

    <?php
    showMessages($msg)
    ?>

    <!-- begin demo HTML code -->
    <div class="row">
        <form class="col" method="post" name="linkEditForm" action="links-update.php">

            <input type="hidden" name="currentLink" value="<?= $link->id ?>">

            <div class="form-group">
                <label for="theTitle">Title</label>
                <input type="text" class="form-control" id="theTitle" name="theTitle"
                       aria-describedby="titleHelp"
                       placeholder="Enter the Title"
                       value="<?= $link->title ?>">
                <small id="titleHelp" class="form-text text-muted">Web page/site title</small>
            </div>

            <div class="form-group">
                <label for="theURL">URL</label>
                <input type="text" class="form-control" id="theURL" name="theURL"
                       aria-describedby="linkCodeHelp"
                       placeholder="Enter the link"
                       value="<?= $link->url ?>">
                <small id="linkCodeHelp" class="form-text text-muted">Web page/site URL</small>
            </div>

            <div class="form-group">
                <label for="linkDescription">Details/Description</label>
                <textarea class="form-control" id="linkDescription" name="linkDescription"
                          aria-describedby="linkDescriptionHelp"
                          placeholder="Enter the link description (optional)"><?= $link->description ?></textarea>
                <small id="linkDescriptionHelp" class="form-text text-muted">Link description</small>
            </div>

            <div class="form-group">
                <label for="tagEntry">Tags</label>
                <input type="text" class="form-control tm-input" id="tagEntry" name="tagEntry"
                       aria-describedby="linkCodeHelp"
                       placeholder="Enter the tags, separated by comma or tab"
                       value="<?= $link->tags ?>">
                <small id="linkCodeHelp" class="form-text text-muted">Tags for site/page</small>
                <input type="hidden" name="theTags" value="<?= $link->tags ?>" id="theTags"/>
            </div>

            <div class="row">
            <span class="col-2">
            <button type="submit" class="btn btn-success w-100">Save</button>
            </span>
                <span class="col-2">
            <a href="links.php" class="btn btn-danger w-100 ml-auto">Cancel</a>
            </span>
            </div>

        </form>
    </div>
    <!-- end demo HTML code -->
    <?php
}

require_once 'footer.php';
