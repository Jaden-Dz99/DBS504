<?php
/**
 * Add link
 *
 * Confirmation for adding the link into the databse
 *
 * @author      Isaac Dinh <20027354@tafe.wa.edu.au>
 * @file        links-create.php
 * @version     1.1
 * @created     2019-05-07
 * @copyright   This work is licensed under Creative Commons
 *              Attribution-ShareAlike 3.0 Australia License.
 */

$title = "ICTDBS504 | JDZ | Links | Add";
require_once "header.php";
require_once "connection.php";
require_once "functions.php";

if (isset($_POST) && count($_POST)>1) {

    // Check to see if the title and url were filled out and that they contain at least 5 and 10 characters respectively
    if (isset($_POST['theTitle'],$_POST['theURL']) && strlen($_POST['theTitle'])> 5 && strlen($_POST['theURL'])> 10) {

        // create an alphabetical list of tags from the submitted ones
        $taggingString = $_POST['theTags'];
        if (strlen($_POST['tagEntry']) > 0) {
            $taggingString .= $_POST['tagEntry'];
        }
        $tagList = explode(',', $taggingString);
        if (!is_null($tagList)) {
            $tagList = array_map('trim', array_filter($tagList));
            $tagList = array_map('stripHash', $tagList);
            $tagList = array_map('stripDot', $tagList);
            natcasesort($tagList);
            $tags = implode(",", $tagList);
        }

        ## remove any HASH sign from the beginning of the title and URL, and also trim any whitepspace
        $title = striphash(trim($_POST['theTitle']));
        $url = stripHash(trim($_POST['theURL']));

        $description = '';
        // see if the description contained any content
        if (isset($_POST['linkDescription']) && strlen($_POST['linkDescription']) > 0) {
            $description = stripHash(trim($_POST['linkDescription']));
        }

        // SQL to create the link
        $sqlBrowse = "INSERT IGNORE INTO links
                                    (title, description, url, tags, created_at, updated_at) 
                                    VALUES (:aTitle, :aNote, :aURL, :aTag, NOW(), NOW())";
        // bind the parameters and execute the SQL
        $stmt = $conn->prepare($sqlBrowse);
        $stmt->bindParam(":aTitle", $title);
        $stmt->bindParam(":aNote", $description);
        $stmt->bindParam(":aURL", $url);
        $stmt->bindParam(":aTag", $tags);

        // execute the insert
        $stmt->execute();

        $msg->success('Link added successfully', 'links-browse.php');

    } else {

        if (!isset($_POST['theTitle'])|| strlen($_POST['theTitle']) <= 5) {
            $msg->Error('You did not give a title for the link');
        }
        if ((!isset($_POST['theURL']) || strlen($_POST['theURL']) <= 10) && $msg->hasMessages()){
            $msg->Error('You did not give a correct (URL) web address', 'links-add.php');
        } else {
            $msg->Error('You did not give a correct (URL) web address', 'links-add.php');
        }
    }
} else {
    // this will have a proper error message later
}
// send the user back to the links main page


$msg->error('Sorry you are unable to come directly to that page', 'links.php');
