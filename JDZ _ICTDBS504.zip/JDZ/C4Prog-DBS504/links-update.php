<?php
/**
 * Update link
 *
 * Updating the information of the link
 *
 * @author      Isaac Dinh <20027354@tafe.wa.edu.au>
 * @file        links-update.php
 * @version     1.1
 * @created     2019-05-07
 * @copyright   This work is licensed under Creative Commons
 *              Attribution-ShareAlike 3.0 Australia License.
 */

$title = "ICTDBS504 | JDZ | Links | Add";
require_once "header.php";
require_once "connection.php";
require_once "functions.php";

if (isset($_POST)) {

    // Check to see if the "newLink" was filled out
    if (isset($_POST['theTitle'],$_POST['currentLink'],$_POST['theURL']) &&
        $_POST['currentLink'] > 0 && strlen($_POST['theTitle']) > 5 && strlen($_POST['theURL']) > 10) {

        $linkID = (int)$_POST['currentLink'];
        $title = trim($_POST['theTitle']);
        $url = trim($_POST['theURL']);
        if (strpos($title, '#') === 0) {
            $title = substr_replace($title, '', 0, 1);
        }

        $description = '';
        // see if the description contained any content
        if (isset($_POST['linkDescription']) && strlen($_POST['linkDescription']) > 0) {
            $description = trim($_POST['linkDescription']);
        }

        $tags = '';
        // see if the description contained any content
        if (isset($_POST['theTags']) && strlen($_POST['theTags']) > 0) {
            $tags = trim($_POST['theTags']);
        }
        if (strlen($_POST['tagEntry']) > 0) {
            $tags .= ','.$_POST['tagEntry'];
        }

        // SQL to create the link
        $sqlBrowse = 'UPDATE links SET title = :aTitle, 
                                       url = :aURL, 
                                       description = :aDescription, 
                                       tags = :aTag 
                                       WHERE id = :aLink';
        // bind the parameters and execute the SQL
        $stmt = $conn->prepare($sqlBrowse);
        $stmt->bindParam(":aTitle", $title, PDO::PARAM_STR);
        $stmt->bindParam(":aURL", $url, PDO::PARAM_STR);
        $stmt->bindParam(":aLink", $linkID, PDO::PARAM_INT);
        $stmt->bindParam(":aTag", $tags, PDO::PARAM_STR);
        $stmt->bindParam(":aDescription", $description, PDO::PARAM_STR);
        // execute the insert
        $stmt->execute();

    } else {
        // Create a proper $msg error here
        echo "Sorry no link given, aborting";
    }
} else {
    // Create a proper $msg error here
    echo "cannot access this page directly";
}

// send the user back to the links main page
header("Location:links-browse.php");