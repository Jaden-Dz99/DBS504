<?php
/**
 * Browse tags
 *
 * A basic browse tags, listing ALL tags in the DB
 *
 * @author      Adrian Gould <adrian.gould@nmtafe.wa.edu.au>
 * @file        tags-browse.php
 * @version     1.0
 * @created     2019-05-07
 * @copyright   This work is licensed under Creative Commons
 *              Attribution-ShareAlike 3.0 Australia License.
 */

$title = "ICTDBS504 | Sample | Tags";
require_once "functions.php";
require_once "connection.php";


// Read the links from the db into an array
// SQL to select all (fields) from the tags from the links
$sqlBrowse = "SELECT tags, created_at FROM links ORDER BY created_at DESC;";

// execute the SQL
$stmt = $conn->prepare($sqlBrowse);
$stmt->execute();

// store results in array
$linkTags = $stmt->fetchAll();


$allTags = [];
$insertTagSQL = "INSERT IGNORE INTO tags ( tag, created_at, updated_at) VALUES ( :tag, :created, :updated);";
$stmt = $conn->prepare($insertTagSQL);

foreach ($linkTags as $link) {
    $tags = $link->tags;
    $created = $link->created_at;
    $tags = str_replace("\"", "", $tags);
    $tags = preg_replace("/^#/", "$", $tags);
    $theTags = explode(",", $tags);
    foreach ($theTags as $theTag) {
        $allTags[] = [$theTag, $created];
    }
}

foreach ($allTags as $tagData) {
    $tag = trim($tagData[0]);
    $created = $tagData[1];
    if (strlen($tag) > 0) {
        $stmt->bindParam(":tag", $tag, PDO::PARAM_STR);
        $stmt->bindParam(":created", $created, PDO::PARAM_STR);
        $stmt->bindParam(":updated", $created, PDO::PARAM_STR);
        $ok = $stmt->execute();
    }
}


header('Location: tags.php');