<?php /** @noinspection SlowArrayOperationsInLoopInspection */
/**
 * Database Functions
 *
 * Collection of general database functions that are performed semi-regularly
 *
 * @author      Jaden Dzubiel <20027451@tafe.wa.edu.au>
 * @file        functions.php
 * @version     1.1
 * @created     2019-05-07
 * @copyright   This work is licensed under Creative Commons
 *              Attribution-ShareAlike 3.0 Australia License.
 */

require_once 'connection.php';

/** Tables used by this application */
$dbTableList = [
    'tags',
    'links',
    'dummy',
    'missing_table'
];

/**
 * retrieve a list of the tables in the SQLite database
 *
 * @param null $conn
 * @return array
 */
if (!function_exists('getTableList')) {
    function getTableList($conn = null)
    {
        try {
            $stmt = $conn->query('SELECT table_name FROM information_schema.tables WHERE table_schema = :database_name;');
            $tables = [];
            while ($row = $stmt->fetch(\PDO::FETCH_OBJ)) {
                $tables[] = $row->name;
            }

            return $tables;
        }
        catch (PDOException $exception) {
            echo '<h1>ERROR!</h1>';
            echo '<h3>Error code: DBF001</h3>';
            echo '<p>We have an error gathering tables.</p>';
            die(0);
        }
    } // end function Get Table List
} // end if


/**
 * retrieve a list of the tables in the SQLite database
 *
 * @param null $conn
 * @return array
 */
if (!function_exists('getTableExists')) {
    function getTableExists($conn = null, $tableName = '')
    {
        $table = $tableName;
        $db = DB_NAME;
        try {
            $sql = 'SELECT table_name FROM information_schema.tables WHERE table_schema = :database_name AND table_name = :table_name;';
            $stmt = $conn->prepare($sql);
            $stmt->bindParam(':table_name', $table, PDO::PARAM_STR);
            $stmt->bindParam(':database_name', $db, PDO::PARAM_STR);
            $stmt->execute();

            $row = $stmt->fetch(\PDO::FETCH_OBJ);
            $tableExists = false;
            if (is_object($row)) {
                $tableExists = true;
            }
            return $tableExists;
        }
        catch (PDOException $exception) {
            echo '<h1>ERROR!</h1>';
            echo '<h3>Error code: DBF002</h3>';
            echo '<p>We have an error verifying table exists.</p>';
            die(0);
        }
    } // end function Get Table List
} // end if

if (!function_exists('countTables')) {
    function countTables($conn = null)
    {
        $count = 0;
        try {
            $stmt = $conn->query('SELECT count(table_name) as count FROM information_schema.tables WHERE table_schema = :database_name');
            $results = $stmt->fetch(\PDO::FETCH_OBJ);
            $count = $results->count;
        }
        catch (PDOException $exception) {
            echo '<h1>ERROR!</h1>';
            echo '<h3>Error code: DBF003</h3>';
            echo '<p>We have an error counting tables.</p>';
            die(0);
        }
        return $count;
    } // end function Get Table List
} // end if


if (!function_exists('rowCount')) {
    function rowCount($conn = null, $tableName)
    {
        try {
            $sql = 'SELECT count(*) as count FROM ' . $tableName;
            $stmt = $conn->prepare($sql);
            $stmt->execute();
            $results = $stmt->fetch(\PDO::FETCH_OBJ);
            $count = $results->count;
            return $count;
        }
        catch (PDOException $exception) {
            echo '<h1>ERROR!</h1>';
            echo '<h3>Error code: DBF004</h3>';
            echo '<p>We have an error with the row count.</p>';
            echo '<p>' . $exception->getMessage() . '</p>';
            echo '<p></p>';
            echo '<p>Table: ' . $tableName . '</p>';
            die(0);
        }
    } // end function Get Table List
} // end if


if (!function_exists('textify')) {
    function textify($string, $replacements = ['_' => ' ', '-' => ' ', '.' => ' ', ':' => ' ',])
    {
        try {
            foreach ($replacements as $replaceThis => $withThis) {
                $string = str_replace($replaceThis, $withThis, $string);
            }
            return $string;
        }
        catch (exception $exception) {
            echo '<h1>ERROR!</h1>';
            echo '<h3>Error code: STR001</h3>';
            echo '<p>We have an error with textify.</p>';
            die(0);
        }
    } // end function Get Table List
} // end if

/*
 *
 * From: https://www.php.net/manual/en/function.money-format.php
 * That it is an implementation of the function money_format for the
 * platforms that do not it bear.
 *
 * The function accepts to same string of format accepts for the
 * original function of the PHP.
 *
 * (Sorry. my writing in English is very bad)
 *
 * The function is tested using PHP 5.1.4 in Windows XP
 * and Apache WebServer.
*/
if (!function_exists('money_format')) {
    function money_format($format, $number)
    {
        $regex = '/%((?:[\^!\-]|\+|\(|\=.)*)([0-9]+)?' .
            '(?:#([0-9]+))?(?:\.([0-9]+))?([in%])/';
        if (setlocale(LC_MONETARY, 0) === 'C') {
            setlocale(LC_MONETARY, '');
        }
        $locale = localeconv();
        preg_match_all($regex, $format, $matches, PREG_SET_ORDER);
        foreach ($matches as $fmatch) {
            $value = (float)$number;
            $flags = array(
                'fillchar'  => preg_match('/\=(.)/', $fmatch[1], $match) ?
                    $match[1] : ' ',
                'nogroup'   => preg_match('/\^/', $fmatch[1]) > 0,
                'usesignal' => preg_match('/\+|\(/', $fmatch[1], $match) ?
                    $match[0] : '+',
                'nosimbol'  => preg_match('/\!/', $fmatch[1]) > 0,
                'isleft'    => preg_match('/\-/', $fmatch[1]) > 0
            );
            $width = trim($fmatch[2]) ? (int)$fmatch[2] : 0;
            $left = trim($fmatch[3]) ? (int)$fmatch[3] : 0;
            $right = trim($fmatch[4]) ? (int)$fmatch[4] : $locale['int_frac_digits'];
            $conversion = $fmatch[5];

            $positive = true;
            if ($value < 0) {
                $positive = false;
                $value *= -1;
            }
            $letter = $positive ? 'p' : 'n';

            $prefix = $suffix = $cprefix = $csuffix = $signal = '';

            $signal = $positive ? $locale['positive_sign'] : $locale['negative_sign'];
            switch (true) {
                case $locale["{$letter}_sign_posn"] == 1 && $flags['usesignal'] === '+':
                    $prefix = $signal;
                    break;
                case $locale["{$letter}_sign_posn"] === 2 && $flags['usesignal'] === '+':
                    $suffix = $signal;
                    break;
                case $locale["{$letter}_sign_posn"] === 3 && $flags['usesignal'] === '+':
                    $cprefix = $signal;
                    break;
                case $locale["{$letter}_sign_posn"] === 4 && $flags['usesignal'] === '+':
                    $csuffix = $signal;
                    break;
                case $flags['usesignal'] === '(':
                case $locale["{$letter}_sign_posn"] === 0:
                    $prefix = '(';
                    $suffix = ')';
                    break;
            }
            if (!$flags['nosimbol']) {
                $currency = $cprefix .
                    ($conversion === 'i' ? $locale['int_curr_symbol'] : $locale['currency_symbol']) .
                    $csuffix;
            } else {
                $currency = '';
            }
            $space = $locale["{$letter}_sep_by_space"] ? ' ' : '';

            $value = number_format($value, $right, $locale['mon_decimal_point'],
                                   $flags['nogroup'] ? '' : $locale['mon_thousands_sep']);
            $value = @explode($locale['mon_decimal_point'], $value);

            $n = strlen($prefix) + strlen($currency) + strlen($value[0]);
            if ($left > 0 && $left > $n) {
                $value[0] = str_repeat($flags['fillchar'], $left - $n) . $value[0];
            }
            $value = implode($locale['mon_decimal_point'], $value);
            if ($locale["{$letter}_cs_precedes"]) {
                $value = $prefix . $currency . $space . $value . $suffix;
            } else {
                $value = $prefix . $value . $space . $currency . $suffix;
            }
            if ($width > 0) {
                $value = str_pad($value, $width, $flags['fillchar'], $flags['isleft'] ?
                    STR_PAD_RIGHT : STR_PAD_LEFT);
            }

            $format = str_replace($fmatch[0], $value, $format);
        }
        return $format;
    } // end function money_format
} // end if


/**
 * retrieve a list of the tables in the SQLite database
 *
 * @param null $conn
 * @return array
 */
if (!function_exists('tagsExpand')) {
    function tagsExpand($taggingString = '')
    {
        $tags = '';
        $tagList = explode(',', $taggingString);
        if (!is_null($tagList)) {
            $tagList = array_map('trim', array_filter($tagList));
            $tagList = array_map('stripHash', $tagList);
            $tagList = array_map('stripDot', $tagList);
            natcasesort($tagList);
            foreach ($tagList as $tag) {
                $tag = htmlentities($tag);
                $tags .= "<span class='badge badge-secondary badge-large'>$tag</span> ";
            }
        }
        return $tags;
    } // end function Get Table List
} // end if

/**
 * Take a multidimension array and flatten it
 *
 * @param $arrayToFlatten
 * @return array
 */
if (!function_exists('flattenArray')) {

    function flattenArray($arrayToFlatten)
    {
        $flatArray = array();
        foreach ($arrayToFlatten as $element) {
            if (is_array($element)) {
                $flatArray = array_merge($flatArray, flattenArray($element));
            } else {
                $flatArray[] = $element;
            }
        }
        return $flatArray;
    }
}

/**
 * trims text to a space then adds ellipses if desired
 *
 * http://www.ebrueggeman.com/blog/abbreviate-text-without-cutting-words-in-half
 *
 * @param string $input      text to trim
 * @param int    $length     in characters to trim to
 * @param bool   $ellipses   if ellipses (...) are to be added
 * @param bool   $strip_html if html tags are to be stripped
 * @return string
 */
if (!function_exists('trim_text')) {

    function trim_text($input, $length, $ellipses = true, $strip_html = true)
    {
        //strip tags, if desired
        if ($strip_html) {
            $input = strip_tags($input);
        }

        //no need to trim, already shorter than trim length
        if (strlen($input) <= $length) {
            return $input;
        }

        //find last space within length
        $last_space = strrpos(substr($input, 0, $length), ' ');
        $trimmed_text = substr($input, 0, $last_space);

        //add ellipses (...)
        if ($ellipses) {
            $trimmed_text .= '...';
        }

        return $trimmed_text;
    }
}

if (!function_exists('stripHash')) {
    function stripHash($string)
    {
        return stripCharacter($string);
    }
}

if (!function_exists('stripDot')) {
    function stripDot($string)
    {
        return stripCharacter($string, '.', 0);
    }
}

if (!function_exists('stripCharacter')) {
    function stripCharacter($string, $char = '#', $from = 1)
    {
        switch ($from) {
            case -1:
                if (strpos($string, $char) === strlen($string) - 1) {
                    $string = substr_replace($string, '', strlen($string) - 1, 1);
                }
                break;
            case 0:
                if (strpos($string, $char) === 0) {
                    $string = substr_replace($string, '', 0, 1);
                }
                if (strpos($string, $char) === strlen($string) - 1) {
                    $string = substr_replace($string, '', strlen($string) - 1, 1);
                }
                break;
            case 1:
                if (strpos($string, $char) === 0) {
                    $string = substr_replace($string, '', 0, 1);
                }
                break;
        }
        return $string;
    }
}
if (!function_exists('showMessages')) {
    function showMessages($msg)
    {
        echo '<div class="row"><div class="col">';
        $msg->display();
        echo '</div></div>';
    }
}