<?php
/**
 * Links
 *
 * A Links homepage that shows basic information on the Links
 *
 * @author      Isaac Dinh <20027354@tafe.wa.edu.au>
 * @file        links.php
 * @version     1.1
 * @created     2019-05-07
 * @copyright   This work is licensed under Creative Commons
 *              Attribution-ShareAlike 3.0 Australia License.
 */

$title = "ICTDBS504 | JDZ | Links";
require_once "functions.php";
require_once "connection.php";
require_once "header.php";

// Read the links from the db into an array
// SQL to select all (fields) from the links
$sqlBrowse = "SELECT title, url, DATE(created_at) as dateAdded FROM links ORDER BY created_at DESC LIMIT 5;";

// execute the SQL
$stmt = $conn->Prepare($sqlBrowse);
$stmt->execute();

// store results in array
$links = $stmt->fetchAll();
// To show a variable for debugging: var_dump($links);


$sqlNumberLinks = "SELECT count(id) as totalLinks FROM links;";
// execute the SQL and get the number of tags
$stmtNumLinks = $conn->prepare($sqlNumberLinks);
$stmtNumLinks->execute();
$numLinks = $stmtNumLinks->fetch();

$searchTerm = '';
$search = '%';
if (isset($_POST['search'])) {
    $searchTerm = $_POST['search'];
    $search = '%' . $searchTerm . '%';
}

?>
    <!-- Details about this demo file -->
    <div class="row">
        <div class="col">
            <h1 class="mt-4"><?= $title; ?></h1>
            <h2 class="text-muted">Last Five Links Added</h2>
            <div class="row">
                <p class="col"><a href="links-browse.php" class="btn btn-primary mb-1">Browse all</a></p>
                <p class="col text-right"><a href="links-add.php" class="btn btn-success mb-1">Add new link</a></p>
                <div class="col">
                    <form class="form-inline" method="post" action="links-browse.php">
                        <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search"
                               name="search" value="<?= $searchTerm ?>">
                        <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
                    </form>
                </div>
            </div>
        </div>
    </div>


<?php
showMessages($msg)
?>


    <!-- begin demo HTML code -->
    <div class="row">

        <div class="col">
            <div class="card w-100  bg-dark">
                <div class="card-body m-0 p-0">
                    <h5 class="card-title m-1 p-3 text-light">Last Five Links</h5>
                    <div class="list-group">
                        <?php
                        foreach ($links as $link) {
                            ?>
                            <a href="<?= $link->url ?>" target="_blank"
                               class="text-dark list-group-item list-group-item-action">
                                <span class="">
                                    <i class="fa fa-link mr-1 pr-1"></i>
                                    <?= trim_text($link->title,60) ?>
                                </span>
                                <span class="small text-black-50" style="display: inline-block">
                                    (<?= $link->dateAdded ?>)
                                </span>
                            </a>
                            <?php
                        } // end for each
                        ?>
                    </div>
                </div>
            </div>
        </div>


        <div class="col">
            <div class="card bg-info text-white" style="width: 100%">
                <div class="card-body text-center">
                    <h5 class="card-title">Total Links</h5>
                    <p class="card-text fa-5x"><?= $numLinks->totalLinks ?></p>
                </div>
            </div>
        </div>

        <div class="col">
            <div class="card text-info" style="width: 100%">
                <div class="card-body ">
                    <h5 class="card-title ">Links vs Date</h5>
                    <div class="card-text w-100">
                        <div id="chart-container">
                            <canvas id="linkGraphCanvas" class="w-100"></canvas>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="p-2"></div>
    <!-- end demo HTML code -->
<?php
require_once 'footer.php';
