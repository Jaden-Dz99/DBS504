<?php
/**
 * Remove link
 *
 * Confirmation for removing the link from the database
 *
 * @author      Isaac Dinh <20027354@tafe.wa.edu.au>
 * @file        links-remove.php
 * @version     1.1
 * @created     2019-05-07
 * @copyright   This work is licensed under Creative Commons
 *              Attribution-ShareAlike 3.0 Australia License.
 */

$title = 'ICTDBS504 | JDZ | Links | Remove';
require_once 'header.php';
require_once 'connection.php';
require_once 'functions.php';

if (isset($_POST)) {

    // Check to see if the "currentLink" and "link" was filled out
    if (isset($_POST['currentLink'], $_POST['link']) && (int)$_POST['currentLink']> 0 && strlen($_POST['link']) > 0) {

        $linkID = (int)$_POST['currentLink'];
        $title = trim($_POST['link']);
        if (strpos($title, '#') === 0) {
            $title = substr_replace($title, '', 0, 1);
        }

        // SQL to create the link
        $sqlBrowse = 'DELETE FROM links WHERE id = :aID AND title = :aTitle';
        // bind the parameters and execute the SQL
        $stmt = $conn->prepare($sqlBrowse);
        $stmt->bindParam(":aTitle", $title, PDO::PARAM_STR);
        $stmt->bindParam(":aID", $linkID, PDO::PARAM_INT);
        // execute the insert
        $stmt->execute();

        $msg->success('Link has been successfully removed', 'links-browse.php');
    }
     else{
        // this will have a proper error message later
        if (!isset($_POST['currentLink'], $_POST['link']) &&
            (int)($_POST['currentLink']) <= 0 || strlen($_POST['link']) <= 0) {
            $msg->error('Incorrect link to be deleted', 'links-browse.php');
        }

    }
}
else {
    $msg->error('Sorry you are unable to come directly to that page', 'links.php');
}

// send the user back to the links main page
$msg->error('Sorry you are unable to come directly to that page', 'links.php');

