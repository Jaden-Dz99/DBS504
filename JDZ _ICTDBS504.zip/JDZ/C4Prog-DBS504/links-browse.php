<?php
/**
 * Browse links
 *
 * A basic browse links, listing ALL links in the DB
 *
 * @author      Isaac Dinh <20027354@tafe.wa.edu.au>
 * @file        links-browse.php
 * @version     1.1
 * @created     2019-05-07
 * @copyright   This work is licensed under Creative Commons
 *              Attribution-ShareAlike 3.0 Australia License.
 */

$title = "ICTDBS504 | JDZ | Links | Browse";
require_once "header.php";
require_once "connection.php";
require_once "functions.php";

// SQL to select all (fields) from the links, looking for a word, or phrase, in the title, description and tags.
// If no text is given then it should return ALL links.
$sqlBrowse = "SELECT * FROM  links 
                WHERE title LIKE :findInTitle
                AND description LIKE :findInDescription
                AND tags LIKE :findInTags
                ORDER BY title ";

$searchTerm = '';
$search = '%';
if (isset($_POST['search'])) {
    $searchTerm = $_POST['search'];
    $search = '%' . $searchTerm . '%';
}

// execute the SQL
$stmt = $conn->prepare($sqlBrowse);
$stmt->bindParam(":findInTitle", $search);
$stmt->bindParam(":findInDescription", $search);
$stmt->bindParam(":findInTags", $search);
$stmt->execute();

// store ALL the results in array
$links = $stmt->fetchAll();

// To show a variable for debugging: var_dump($links);
?>
<!-- Details about this demo file -->
<div class="row">
    <div class="col">
        <h1 class="mt-4"><?= $title; ?></h1>
        <h2 class="text-muted">Browse Links</h2>
        <div class="row">
            <p class="col-2">
                <a href="links-browse.php" class="btn btn-primary mb-1">Browse all</a>
            </p>
            <p class="col">
                <a href="links-add.php" class="btn btn-success mb-1">
                    <i class="fa fa-plus"></i> New Link
                </a>
            </p>
            <div class="col">
                <form class="form-inline" method="post">
                    <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search"
                           name="search" value="<?= $searchTerm ?>">
                    <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
                </form>
            </div>
        </div>
    </div>
</div>

<?php
showMessages($msg)
?>

<!-- begin demo HTML code -->
<div class="row">
    <div class="col">
        <table class="table">
            <thead>
            <tr>
                <th>Link</th>
                <th>Date Added</th>
                <th>Actions</th>
            </tr>
            </thead>

            <tbody>
            <?php
            foreach ($links as $link) {
                ?>
                <tr>
                    <td>
                        <p>
                            <a href="<?= $link->url ?>" class="btn-link text-body">
                                <i class="fa fa-external-link-alt text-primary"></i>
                                <?= trim_text($link->title, 80) ?>
                                <br>
                                <span class="text-muted small"><?= trim_text($link->description, 80) ?></span>
                            </a>

                        </p>
                    </td>
                    <td class="small"><?= $link->created_at ?></td>
                    <td>
                        <form action="links-browse.php" method="post">
                            <input type="hidden" name="link" value="<?= $link->id ?>">
                            <div class="btn-group" role="group" aria-label="Basic example">
                                <button type="submit" class="btn btn-success" formaction="links-read.php"
                                        name="btnRead">
                                    <i class="fa fa-eye"></i>
                                </button>
                                <button type="submit" class="btn btn-warning" formaction="links-edit.php"
                                        name="btnEdit">
                                    <i class="fa fa-pen"></i>
                                </button>
                                <button type="submit" class="btn btn-danger" formaction="links-delete.php"
                                        name="btnDelete">
                                    <i class="fa fa-times"></i>
                                </button>
                            </div>
                        </form>
                    </td>
                </tr>
                <?php
            } // end for each
            ?>
            </tbody>
        </table>
    </div>
</div>
<!-- end demo HTML code -->
<?php

include_once 'footer.php';