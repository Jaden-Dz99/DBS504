<?php
/**
 * Read links
 *
 * A basic read links, listing ALL links in the DB
 *
 * @author      Adrian Gould <adrian.gould@nmtafe.wa.edu.au>
 * @file        links-read.php
 * @version     1.0
 * @created     2019-05-07
 * @copyright   This work is licensed under Creative Commons
 *              Attribution-ShareAlike 3.0 Australia License.
 */

$title = "ICTDBS504 | JDZ | Links | Read";
require_once "header.php";
require_once "connection.php";
require_once "functions.php";

if (!isset($_POST)||!isset($_POST['link'])) {
    $error = ["warning" => "Cannot come directly to this page"];
} else {

    $linkToFind = $_POST['link'];
// Read the links from the db into an array
    $sqlRead = "SELECT l.id, l.title, l.description, l.url, l.tags, l.created_at, l.updated_at FROM links as l WHERE id = :linkToFind ";
// execute the SQL
    $stmt = $conn->prepare($sqlRead);
    $stmt->bindParam(':linkToFind', $linkToFind, PDO:: PARAM_INT);
    $stmt->execute();
// store results in array
    $links = $stmt->fetchAll();
    ?>
    <!-- Details about this demo file -->
    <div class="row">
        <div class="col">
            <h1 class="mt-4"><?= $title; ?></h1>
            <h2 class="text-muted">Read Link</h2>
            <div class="row">
                <p class="col"><a href="links-browse.php" class="btn btn-primary mb-1">Browse all</a></p>
                <p class="col text-right">
                    <a href="links-add.php" class="btn btn-success mb-1"><i class="fa fa-plus"></i> New link</a>
                </p>
            </div>
        </div>
    </div>

    <!-- begin demo HTML code -->
    <div class="row">
        <div class="col">
            <?php
            foreach ($links as $link) {
                ?>
                <table class="table">
                    <thead>
                    </thead>

                    <tbody>
                    <tr>
                        <th>Link</th>
                        <td><?= $link->title ?></td>
                    </tr>
                    <tr>
                        <th>URL</th>
                        <td><?= $link->url ?></td>
                    </tr>
                    <tr>
                        <th>Notes</th>
                        <td><?= $link->description ?></td>
                    </tr>
                    <tr>
                        <th>Tags</th>
                        <td><?= tagsExpand($link->tags) ?></td>
                    </tr>
                    <tr>
                        <th>Date Added</th>
                        <td><?= $link->created_at ?></td>
                    </tr>
                    <tr>
                        <th>Date Updated</th>
                        <td><?= $link->updated_at?></td>
                    </tr>

                    </tbody>
                </table>
                <form action="links-browse.php" method="post">
                    <input type="hidden" name="link" value="<?= $link->id ?>">
                    <div class="btn-group" role="group" aria-label="Basic example">
                        <button type="submit" class="btn btn-warning" formaction="links-edit.php">
                            <i class="fa fa-pen"></i> Edit Link
                        </button>
                        <button type="submit" class="btn btn-danger" formaction="links-delete.php">
                            <i class="fa fa-times"></i> Delete
                        </button>
                    </div>
                </form>
                <?php
            } // end for each
            ?>
        </div>
    </div>
    <!-- end demo HTML code -->
    <?php
}
include_once 'footer.php';

