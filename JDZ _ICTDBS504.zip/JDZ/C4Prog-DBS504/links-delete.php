<?php
/**
 * Delete Links
 *
 * Deleting the links from the database
 *
 * @author      Isaac Dinh <20027354@tafe.wa.edu.au>
 * @file        links-delete.php
 * @version     1.1
 * @created     2019-05-07
 * @copyright   This work is licensed under Creative Commons
 *              Attribution-ShareAlike 3.0 Australia License.
 */

$title = "ICTDBS504 | JDZ | Links | Delete";
require_once "header.php";
require_once "connection.php";
require_once "functions.php";

if (!isset($_POST) || !isset($_POST['link'])) {
    $error = ["warning" => "Cannot come directly to this page", 'links-browse.php'];
} else {

    $linkToFind = (int)trim($_POST['link']);

    // Read the link that is to be deleted
    $sqlRead = "SELECT t.id, t.title, t.description, t.url, t.tags, t.created_at, t.updated_at FROM links as t WHERE id = :linkToFind";
    // execute the SQL
    $stmt = $conn->prepare($sqlRead);
    $stmt->bindparam( ':linkToFind', $linkToFind);
    $stmt->execute();
    // store results in array
    $link = $stmt->fetch();

    ?>
    <!-- Details about this demo file -->
    <div class="row">
        <div class="col">
            <h1 class="mt-4"> $title </h1>
            <h2 class="text-muted">Delete Link</h2>
            <div class="row">
                <p class="col"><a href="links-brows.php" class="btn btn-primary mb-1">Browse all</a></p>
                <p class="col text-right">
                    <a href="links-add.php" class="btn btn-success mb-1"><i class="fa fa-plus"></i> New link</a>
                </p>
            </div>
        </div>
    </div>

    <?php
    showMessages($msg)
    ?>

    <!-- begin demo HTML code -->
    <div class="row">
        <div class="col">
            <table class="table">
                <thead>
                </thead>

                <tbody>
                <tr>
                    <th>Link</th>
                    <td><?= $link->title ?></td>
                </tr>
                <tr>
                    <th>URL</th>
                    <td><?= $link->url ?></td>
                </tr>
                <tr>
                    <th>Notes</th>
                    <td><?= $link->description ?></td>
                </tr>
                <tr>
                    <th>Tags</th>
                    <td><?= tagsExpand($link->tags) ?></td>
                </tr>
                <tr>
                    <th>Date Added</th>
                    <td><?= $link->created_at ?></td>
                </tr>
                <tr>
                    <th>Date Updated</th>
                    <td><?= $link->updated_at ?></td>
                </tr>

                </tbody>
            </table>
            <form action="links-browse.php" method="post">
                <input type="hidden" name="link" value="<?= $link->title ?>">
                <input type="hidden" name="currentLink" value="<?= $link->id ?>">
                <div class="btn-group" role="group" aria-label="Basic example">
                    <button type="submit" class="btn btn-danger" formaction="links-remove.php">
                        <i class="fa fa-exclamation"></i> Confirm Delete
                    </button>
                    <a class="btn btn-dark" href="links-browse.php">
                        <i class="fa fa-smile"></i> Cancel Delete
                    </a>
                </div>
            </form>

        </div>
    </div>
    <!-- end demo HTML code -->
    <?php
}
