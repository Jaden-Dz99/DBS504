

// Cheating by using jQuery to fill in the dynamic data
//

/**
 * Show a dynamic Chart from given data.
 *
 * @param apiToCall
 * @param targetCanvas
 */
function showGraph(apiToCall, targetCanvas = "#graphCanvas") {
    {
        $.post(apiToCall,
            function (data) {
                Chart.defaults.global.legend.display = false;
                Chart.defaults.global.animation.easing = 'easeInOutExpo';

                console.log(data);
                let aDate = [];
                let taggings = [];

                for (let i in data) {
                    aDate.push(data[i].theDate);
                    taggings.push(data[i].total);
                }

                let chartdata = {
                    labels: aDate,
                    datasets: [
                        {
                            backgroundColor: '#17a2b8',
                            borderColor: '#077288',
                            hoverBackgroundColor: '#CCCCCC',
                            hoverBorderColor: '#666666',
                            data: taggings
                        }
                    ],
                };

                let graphTarget = $(targetCanvas);

                let barGraph = new Chart(graphTarget, {
                    type: 'line',
                    data: chartdata,
                    options: {
                        tooltips: {
                            callbacks: {
                                label: tooltipItem => `${tooltipItem.yLabel} ${tooltipItem.xLabel}`,
                                title: () => null,
                            }
                        },
                        scales: {
                            xAxes: [{
                                barPercentage: 0.8,
                                minBarLength: 2,
                                gridLines: {
                                    offsetGridLines: false
                                }
                            }],
                            yAxes: [{
                                display: true,
                                ticks: {
                                    suggestedMin: 0,    // minimum will be 0, unless there is a lower value.
                                }
                            }]
                        }
                    }
                });
            }
        );
    }
}

/**
 * When the document is ready, check for locations and update them if they are present
 */
$(document).ready(function () {

    /**
     * Check for the Tags Manager Input, if there, activate the tags manager
     */
    $(".tm-input").tagsManager({
        output: '#theTags',
        tagClass: 'tm-tag-secondary',
        CapitalizeFirstLetter: false,
    });

    /**
     * Check to see if the Tags Graph Canvas is present, if so fill it
     */
    if ($("#graphCanvas").length) {
        showGraph("tags-api.php");
    }

    /**
     * Check to see if the Links Graph Canvas is present, if so fill it
     */
    if ($("#linkGraphCanvas").length) {
        showGraph("links-api.php", "#linkGraphCanvas");
    }
});
