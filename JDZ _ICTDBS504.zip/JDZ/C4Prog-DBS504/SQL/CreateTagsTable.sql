CREATE TABLE IF NOT EXISTS tags (
                                    id INTEGER(11) ________ ___ ____ ______________,
                                    tag VARCHAR (__),
 description _______ (255),
 created_at ________ DEFAULT '__________ ________',
 updated_at DATETIME DEFAULT '1000-01-01 00:00:00',
 PRIMARY KEY (id),
 UNIQUE(_______)
);