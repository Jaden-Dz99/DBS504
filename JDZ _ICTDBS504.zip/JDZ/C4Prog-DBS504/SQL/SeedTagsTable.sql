INSERT IGNORE INTO tags
        (id, tag, description, created_at, updated_at)
VALUES  (1, 'TAFE', 'Technical And Further Education', DATE_SUB(NOW(), INTERVAL 20 DAY),
            DATE_SUB(NOW(), INTERVAL 20 DAY));

INSERT IGNORE INTO tags
        (id, tag, description, created_at, updated_at)
VALUES  (2, 'ECMAScript', '', DATE_SUB(NOW(), INTERVAL 19 DAY), DATE_SUB(NOW(), INTERVAL 19 DAY));

INSERT IGNORE INTO tags
        (id, tag, description, created_at, updated_at)
VALUES  (3, 'PHP', '', DATE_SUB(NOW(), INTERVAL 17 DAY), DATE_SUB(NOW(), INTERVAL 17 DAY)),
        (4, 'MySQL', '', DATE_SUB(NOW(), INTERVAL 15 DAY), DATE_SUB(NOW(), INTERVAL 15 DAY)),
        (5, 'Database', '', DATE_SUB(NOW(), INTERVAL 15 DAY), DATE_SUB(NOW(), INTERVAL 15 DAY)),
        (6, 'Bootstrap', 'Web front end framework', DATE_SUB(NOW(), INTERVAL 15 DAY),
            DATE_SUB(NOW(), INTERVAL 15 DAY)),
        (7, 'JavaScript', 'Web front-end and back-end programming language, also correctly known as ECMAScript',
            DATE_SUB(NOW(), INTERVAL 15 SECOND), NOW()),
        (8, 'AJAX', 'Asynchronous JavaScript and XML',
            DATE_SUB(NOW(), INTERVAL 15 DAY), DATE_SUB(NOW(), INTERVAL 10 DAY)),
        (9, 'LMS', 'Initialism for Learning Management System', NOW(), NOW()),
        (10, 'Object Oriented Programming', 'also known as OOP',
            DATE_SUB(NOW(), INTERVAL 20 DAY), DATE_SUB(NOW(), INTERVAL 17 DAY)),
        (11, 'OOP', 'Object Oriented Programming',DATE_SUB(NOW(),
            INTERVAL 10 SECOND), NOW()),
        (12, 'Class', '', NOW(), NOW());

## Add your SQL to create the additional tags after this line



## Do not add any more tags after this line
