INSERT IGNORE INTO links
    (id, title, url, description, tags, created_at, updated_at)
VALUES (1, "Adrian’s Diigo Account", "https://diigo.com/user/ady_gould",
        "Adrian’s Diigo account. Contains HUGE numbers of links to sites with information on SQL, PHP, C#, JavaScript, Java, Web and more.",
        "Java, SQL, MySQL, Javascript, PHP, Databases, web sites, web development",
        "2017-04-01 00:00:00", "2017-04-01 00:00:00");

INSERT IGNORE INTO links
    (id, title, url, description, tags, created_at, updated_at)
VALUES (2, "North Metropolitan TAFE", "https://northmetrotafe.wa.edu.au",
        "",
        "TAFE, North Metro, Study, Certificate IV, Programming",
        "2017-04-01 00:00:00", "2017-04-01 00:00:00"),

       (4, "The Only Proper PHP-PDO Tutorial", "https://phpdelusions.net/pdo",
        "",
        "PHP, MySQL, PDO,",
        "2017-04-01 00:00:00", "2017-04-01 00:00:00");

## Add the other links after this line
INSERT IGNORE INTO links
    (id, title, url, description, tags, created_at, updated_at)
VALUES (5, "Webd 153 Pagination with PDO", "https://youtu.be/TI78ax23qZg",
        "",
        "#PHP, #MySQL, #pagination, #PDO,",
        "2017-04-01 00:00:00", "2017-04-01 00:00:00");
/* Affected rows: 1  Found rows: 0  Warnings: 0  Duration for 1 query: 0.032 sec. */
INSERT IGNORE INTO links
    (id, title, url, description, tags, created_at, updated_at)
VALUES (8, "Pagination with PHP and PDO", "https://phpro.org/tutorials/Pagination-with-PHP-and-PDO.html",
        "We have all seen the little menus at the top of a page like the one shown here…
<< PREV- 1 2 3 4 5 -NEXT >>
These little menus allow us to navigate a group of results much easier than simply dumping hundreds of results to a single page. A more manageable solution is to break the data up into smaller chunks to allow the end user to better view them. This method also allows for simple navigation through the result set quickly by allowing us to jump to any page of results.
",
        "#php, #video, #bootstrap, #pdo",
        "2017-04-01 00:00:00", "2017-04-01 00:00:00");
/* Affected rows: 1  Found rows: 0  Warnings: 0  Duration for 1 query: 0.031 sec. */

INSERT IGNORE INTO links
    (id, title, url, description, tags, created_at, updated_at)
VALUES (3, "Webopedia C#", "https://www.webopedia.com/TERM/C/C_sharp.html",
        "Website about c#",
        "#c#, #programming, #cert IV",
        "2017-04-01 00:00:00", "2017-04-01 00:00:00");
/* Affected rows: 1  Found rows: 0  Warnings: 0  Duration for 1 query: 0.031 sec. */
INSERT IGNORE INTO links
    (id, title, url, description, tags, created_at, updated_at)
VALUES (6, "What is JavaScript?", "https://developer.mozilla.org/en-US/docs/Web/JavaScript/About_JavaScript",
        "Website about javascript",
        "#javascript, #programming, #cert IV",
        "2017-04-01 00:00:00", "2017-04-01 00:00:00");
/* Affected rows: 1  Found rows: 0  Warnings: 0  Duration for 1 query: 0.031 sec. */

INSERT IGNORE INTO links
    (id, title, url, description, tags, created_at, updated_at)
VALUES (7, "A BEGINNER’S GUIDE TO SQL", "https://learntocodewith.me/posts/sql-guide/",
        "Website about sql",
        "#sql #learntocode",
        "2017-04-01 00:00:00", "2017-04-01 00:00:00");
/* Affected rows: 1  Found rows: 0  Warnings: 0  Duration for 1 query: 0.047 sec. */
INSERT IGNORE INTO links
    (id, title, url, description, tags, created_at, updated_at)
VALUES (9, "PHPStorm Quick start guide ", "https://www.jetbrains.com/help/phpstorm/quick-start-guide-phpstorm.html",
        "",
        "#jetbrains #phpstorm",
        "2017-04-01 00:00:00", "2017-04-01 00:00:00");
/* Affected rows: 1  Found rows: 0  Warnings: 0  Duration for 1 query: 0.031 sec. */
INSERT IGNORE INTO links
    (id, title, url, description, tags, created_at, updated_at)
VALUES (9, "PHPStorm Quick start guide ", "https://www.jetbrains.com/help/phpstorm/quick-start-guide-phpstorm.html",
        "",
        "#jetbrains #phpstorm",
        "2017-04-01 00:00:00", "2017-04-01 00:00:00");
/* Affected rows: 0  Found rows: 0  Warnings: 1  Duration for 1 query: 0.000 sec. */

INSERT IGNORE INTO links
    (id, title, url, description, tags, created_at, updated_at)
VALUES (10, "Compiling and Running Java Code with jGrasp", "https://kyledewey.github.io/comp110-fall17/resources/compiling_and_running_java_code_in_jgrasp/",
        "",
        "#java #jgrasp",
        "2017-04-01 00:00:00", "2017-04-01 00:00:00");
/* Affected rows: 1  Found rows: 0  Warnings: 0  Duration for 1 query: 0.031 sec. */